webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-toastify */ "./node_modules/react-toastify/dist/react-toastify.esm.js");
/* harmony import */ var react_lottie__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-lottie */ "./node_modules/react-lottie/dist/index.js");
/* harmony import */ var react_lottie__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_lottie__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../styles/pages/Signin.module.css */ "./styles/pages/Signin.module.css");
/* harmony import */ var _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../services/api */ "./services/api.js");
/* harmony import */ var _utils_validation_SigninValidation__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/validation/SigninValidation */ "./utils/validation/SigninValidation.js");
/* harmony import */ var _components_Message__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../components/Message */ "./components/Message/index.js");
/* harmony import */ var _assets_animation_9953_loading_round_json__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../assets/animation/9953-loading-round.json */ "./assets/animation/9953-loading-round.json");
var _assets_animation_9953_loading_round_json__WEBPACK_IMPORTED_MODULE_12___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../assets/animation/9953-loading-round.json */ "./assets/animation/9953-loading-round.json", 1);




var _jsxFileName = "C:\\Users\\Kaio\\Desktop\\migration\\pages\\index.js",
    _s = $RefreshSig$();





 //Falta criar as classes







function SignIn() {
  _s();

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(''),
      email = _useState[0],
      setEmail = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(''),
      password = _useState2[0],
      setPassword = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(false),
      loading = _useState3[0],
      setLoading = _useState3[1];

  var defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: _assets_animation_9953_loading_round_json__WEBPACK_IMPORTED_MODULE_12__,
    rendererSettings: {
      preserveAspectRatio: 'xMidYMid slice'
    }
  };

  function HandleSubmit() {
    return _HandleSubmit.apply(this, arguments);
  }

  function _HandleSubmit() {
    _HandleSubmit = Object(C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
      var data, validation;
      return C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              setLoading(true);
              data = {
                email: email,
                password: password
              };
              _context.next = 4;
              return Object(_utils_validation_SigninValidation__WEBPACK_IMPORTED_MODULE_10__["default"])(data);

            case 4:
              validation = _context.sent;

              if (!validation) {
                _context.next = 10;
                break;
              }

              _context.next = 8;
              return _services_api__WEBPACK_IMPORTED_MODULE_9__["default"].post('/signin', data).then(function (response) {
                localStorage.setItem("over_name", response.data.user.name);
                localStorage.setItem("over_token", response.data.token);
                Object(_components_Message__WEBPACK_IMPORTED_MODULE_11__["default"])(response);
                setTimeout(function () {
                  setLoading(false);
                  handleAuthenticated();
                }, 2000);
              })["catch"](function (error) {
                Object(_components_Message__WEBPACK_IMPORTED_MODULE_11__["default"])(error.response.data.message);
                setTimeout(function () {
                  setLoading(false);
                }, 2000);
              });

            case 8:
              _context.next = 12;
              break;

            case 10:
              Object(_components_Message__WEBPACK_IMPORTED_MODULE_11__["default"])("Preencha um email válido e uma senha de no mínimo 6 caracteres!");
              setTimeout(function () {
                setLoading(false);
              }, 2000);

            case 12:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));
    return _HandleSubmit.apply(this, arguments);
  }

  function handleAuthenticated() {
    return _handleAuthenticated.apply(this, arguments);
  }

  function _handleAuthenticated() {
    _handleAuthenticated = Object(C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
      var token;
      return C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return localStorage.getItem("over_token");

            case 2:
              token = _context2.sent;

              if (token) {
                window.location = "/";
              }

            case 4:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));
    return _handleAuthenticated.apply(this, arguments);
  }

  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])(function () {
    handleAuthenticated();
  }, []);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
    className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.container,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.form,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(react_toastify__WEBPACK_IMPORTED_MODULE_6__["ToastContainer"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("input", {
        className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.input,
        type: "email",
        placeholder: "E-mail",
        onChange: function onChange(e) {
          return setEmail(e.target.value);
        },
        required: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("input", {
        className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.input,
        type: "password",
        placeholder: "Senha",
        onChange: function onChange(e) {
          return setPassword(e.target.value);
        },
        required: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
        href: "/forgot-password",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("a", {
          className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.forgotPassword,
          children: "Esqueceu sua senha?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 95,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 92,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("button", {
        className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.button,
        onClick: HandleSubmit,
        children: loading ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
          className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.animation,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(react_lottie__WEBPACK_IMPORTED_MODULE_7___default.a, {
            options: defaultOptions
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 106,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 105,
          columnNumber: 13
        }, this) : "Entrar"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 100,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
        href: "/signup",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("a", {
          className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.signin,
          children: ["Ainda n\xE3o tem cadastro?", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("span", {
            className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.span,
            children: "Cadastra-se!"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 117,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 116,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 113,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 76,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 75,
    columnNumber: 5
  }, this);
}

_s(SignIn, "NTuBuTewpujiBTusgv9ZxvtgOf0=");

_c = SignIn;
/* harmony default export */ __webpack_exports__["default"] = (SignIn);

var _c;

$RefreshReg$(_c, "SignIn");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwibmFtZXMiOlsiU2lnbkluIiwidXNlU3RhdGUiLCJlbWFpbCIsInNldEVtYWlsIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZGVmYXVsdE9wdGlvbnMiLCJsb29wIiwiYXV0b3BsYXkiLCJhbmltYXRpb25EYXRhIiwiY2hlY2tBbmltYXRpb24iLCJyZW5kZXJlclNldHRpbmdzIiwicHJlc2VydmVBc3BlY3RSYXRpbyIsIkhhbmRsZVN1Ym1pdCIsImRhdGEiLCJTaWduaW5WYWxpZGF0aW9uIiwidmFsaWRhdGlvbiIsImFwaSIsInBvc3QiLCJ0aGVuIiwicmVzcG9uc2UiLCJsb2NhbFN0b3JhZ2UiLCJzZXRJdGVtIiwidXNlciIsIm5hbWUiLCJ0b2tlbiIsIk1lc3NhZ2UiLCJzZXRUaW1lb3V0IiwiaGFuZGxlQXV0aGVudGljYXRlZCIsImVycm9yIiwibWVzc2FnZSIsImdldEl0ZW0iLCJ3aW5kb3ciLCJsb2NhdGlvbiIsInVzZUVmZmVjdCIsInN0eWxlcyIsImNvbnRhaW5lciIsImZvcm0iLCJpbnB1dCIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImZvcmdvdFBhc3N3b3JkIiwiYnV0dG9uIiwiYW5pbWF0aW9uIiwic2lnbmluIiwic3BhbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7Q0FHQTs7QUFDQTtBQUVBO0FBRUE7QUFDQTtBQUVBOztBQUVBLFNBQVNBLE1BQVQsR0FBa0I7QUFBQTs7QUFBQSxrQkFDVUMsc0RBQVEsQ0FBQyxFQUFELENBRGxCO0FBQUEsTUFDVEMsS0FEUztBQUFBLE1BQ0ZDLFFBREU7O0FBQUEsbUJBRWdCRixzREFBUSxDQUFDLEVBQUQsQ0FGeEI7QUFBQSxNQUVURyxRQUZTO0FBQUEsTUFFQ0MsV0FGRDs7QUFBQSxtQkFHY0osc0RBQVEsQ0FBQyxLQUFELENBSHRCO0FBQUEsTUFHVEssT0FIUztBQUFBLE1BR0FDLFVBSEE7O0FBS2hCLE1BQU1DLGNBQWMsR0FBRztBQUNyQkMsUUFBSSxFQUFFLElBRGU7QUFFckJDLFlBQVEsRUFBRSxJQUZXO0FBR3JCQyxpQkFBYSxFQUFFQyx1RUFITTtBQUlyQkMsb0JBQWdCLEVBQUU7QUFDaEJDLHlCQUFtQixFQUFFO0FBREw7QUFKRyxHQUF2Qjs7QUFMZ0IsV0FjREMsWUFkQztBQUFBO0FBQUE7O0FBQUE7QUFBQSwyUkFjaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0VSLHdCQUFVLENBQUMsSUFBRCxDQUFWO0FBQ01TLGtCQUZSLEdBRWU7QUFBRWQscUJBQUssRUFBTEEsS0FBRjtBQUFTRSx3QkFBUSxFQUFSQTtBQUFULGVBRmY7QUFBQTtBQUFBLHFCQUl5QmEsbUZBQWdCLENBQUNELElBQUQsQ0FKekM7O0FBQUE7QUFJTUUsd0JBSk47O0FBQUEsbUJBTUtBLFVBTkw7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSxxQkFPVUMscURBQUcsQ0FBQ0MsSUFBSixDQUFTLFNBQVQsRUFBb0JKLElBQXBCLEVBQ0xLLElBREssQ0FDQSxVQUFBQyxRQUFRLEVBQUk7QUFDaEJDLDRCQUFZLENBQUNDLE9BQWIsQ0FBcUIsV0FBckIsRUFBa0NGLFFBQVEsQ0FBQ04sSUFBVCxDQUFjUyxJQUFkLENBQW1CQyxJQUFyRDtBQUNBSCw0QkFBWSxDQUFDQyxPQUFiLENBQXFCLFlBQXJCLEVBQW1DRixRQUFRLENBQUNOLElBQVQsQ0FBY1csS0FBakQ7QUFDQUMsb0ZBQU8sQ0FBQ04sUUFBRCxDQUFQO0FBQ0FPLDBCQUFVLENBQUMsWUFBTTtBQUNmdEIsNEJBQVUsQ0FBQyxLQUFELENBQVY7QUFDQXVCLHFDQUFtQjtBQUNwQixpQkFIUyxFQUdQLElBSE8sQ0FBVjtBQUlELGVBVEssV0FVQyxVQUFBQyxLQUFLLEVBQUs7QUFDZkgsb0ZBQU8sQ0FBQ0csS0FBSyxDQUFDVCxRQUFOLENBQWVOLElBQWYsQ0FBb0JnQixPQUFyQixDQUFQO0FBQ0FILDBCQUFVLENBQUMsWUFBTTtBQUNmdEIsNEJBQVUsQ0FBQyxLQUFELENBQVY7QUFDRCxpQkFGUyxFQUVQLElBRk8sQ0FBVjtBQUdELGVBZkssQ0FQVjs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUF3QklxQixrRkFBTyxDQUFDLGlFQUFELENBQVA7QUFDQUMsd0JBQVUsQ0FBQyxZQUFNO0FBQ2Z0QiwwQkFBVSxDQUFDLEtBQUQsQ0FBVjtBQUNELGVBRlMsRUFFUCxJQUZPLENBQVY7O0FBekJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBZGdCO0FBQUE7QUFBQTs7QUFBQSxXQTZDRHVCLG1CQTdDQztBQUFBO0FBQUE7O0FBQUE7QUFBQSxrU0E2Q2hCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQ29CUCxZQUFZLENBQUNVLE9BQWIsQ0FBcUIsWUFBckIsQ0FEcEI7O0FBQUE7QUFDTU4sbUJBRE47O0FBR0Usa0JBQUdBLEtBQUgsRUFBVTtBQUNSTyxzQkFBTSxDQUFDQyxRQUFQLEdBQWtCLEdBQWxCO0FBQ0Q7O0FBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0E3Q2dCO0FBQUE7QUFBQTs7QUFxRGhCQyx5REFBUyxDQUFDLFlBQU07QUFDZE4sdUJBQW1CO0FBQ3BCLEdBRlEsRUFFTixFQUZNLENBQVQ7QUFJQSxzQkFDRTtBQUFLLGFBQVMsRUFBRU8sc0VBQU0sQ0FBQ0MsU0FBdkI7QUFBQSwyQkFDRTtBQUFLLGVBQVMsRUFBRUQsc0VBQU0sQ0FBQ0UsSUFBdkI7QUFBQSw4QkFDRSxxRUFBQyw2REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUNFLGlCQUFTLEVBQUVGLHNFQUFNLENBQUNHLEtBRHBCO0FBRUUsWUFBSSxFQUFDLE9BRlA7QUFHRSxtQkFBVyxFQUFDLFFBSGQ7QUFJRSxnQkFBUSxFQUFFLGtCQUFDQyxDQUFEO0FBQUEsaUJBQU90QyxRQUFRLENBQUNzQyxDQUFDLENBQUNDLE1BQUYsQ0FBU0MsS0FBVixDQUFmO0FBQUEsU0FKWjtBQUtFLGdCQUFRO0FBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGLGVBU0U7QUFDRSxpQkFBUyxFQUFFTixzRUFBTSxDQUFDRyxLQURwQjtBQUVFLFlBQUksRUFBQyxVQUZQO0FBR0UsbUJBQVcsRUFBQyxPQUhkO0FBSUUsZ0JBQVEsRUFBRSxrQkFBQ0MsQ0FBRDtBQUFBLGlCQUFPcEMsV0FBVyxDQUFDb0MsQ0FBQyxDQUFDQyxNQUFGLENBQVNDLEtBQVYsQ0FBbEI7QUFBQSxTQUpaO0FBS0UsZ0JBQVE7QUFMVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVEYsZUFnQkUscUVBQUMsZ0RBQUQ7QUFDRSxZQUFJLEVBQUMsa0JBRFA7QUFBQSwrQkFHRTtBQUFHLG1CQUFTLEVBQUVOLHNFQUFNLENBQUNPLGNBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWhCRixlQXdCRTtBQUNFLGlCQUFTLEVBQUVQLHNFQUFNLENBQUNRLE1BRHBCO0FBRUUsZUFBTyxFQUFFOUIsWUFGWDtBQUFBLGtCQUlJVCxPQUFPLGdCQUNQO0FBQUssbUJBQVMsRUFBRStCLHNFQUFNLENBQUNTLFNBQXZCO0FBQUEsaUNBQ0UscUVBQUMsbURBQUQ7QUFBUSxtQkFBTyxFQUFFdEM7QUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRE8sR0FNTDtBQVZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F4QkYsZUFxQ0UscUVBQUMsZ0RBQUQ7QUFDRSxZQUFJLEVBQUMsU0FEUDtBQUFBLCtCQUdFO0FBQUcsbUJBQVMsRUFBRTZCLHNFQUFNLENBQUNVLE1BQXJCO0FBQUEsZ0VBQ0U7QUFBTSxxQkFBUyxFQUFFVixzRUFBTSxDQUFDVyxJQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQWtERDs7R0EzR1FoRCxNOztLQUFBQSxNO0FBNkdNQSxxRUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC4yNGRjZmEyYWY3M2E3MzJhZjE0Mi5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBJbWFnZSBmcm9tICduZXh0L2ltYWdlJztcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluayc7XG5pbXBvcnQgeyBUb2FzdENvbnRhaW5lciB9IGZyb20gJ3JlYWN0LXRvYXN0aWZ5JztcbmltcG9ydCBMb3R0aWUgZnJvbSAncmVhY3QtbG90dGllJztcblxuLy9GYWx0YSBjcmlhciBhcyBjbGFzc2VzXG5pbXBvcnQgc3R5bGVzIGZyb20gJy4uL3N0eWxlcy9wYWdlcy9TaWduaW4ubW9kdWxlLmNzcyc7XG5cbmltcG9ydCBhcGkgZnJvbSAnLi4vc2VydmljZXMvYXBpJztcblxuaW1wb3J0IFNpZ25pblZhbGlkYXRpb24gZnJvbSAnLi4vdXRpbHMvdmFsaWRhdGlvbi9TaWduaW5WYWxpZGF0aW9uJztcbmltcG9ydCBNZXNzYWdlIGZyb20gJy4uL2NvbXBvbmVudHMvTWVzc2FnZSc7XG5cbmltcG9ydCBjaGVja0FuaW1hdGlvbiBmcm9tICcuLi9hc3NldHMvYW5pbWF0aW9uLzk5NTMtbG9hZGluZy1yb3VuZC5qc29uJztcblxuZnVuY3Rpb24gU2lnbkluKCkge1xuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBkZWZhdWx0T3B0aW9ucyA9IHtcbiAgICBsb29wOiB0cnVlLFxuICAgIGF1dG9wbGF5OiB0cnVlLCBcbiAgICBhbmltYXRpb25EYXRhOiBjaGVja0FuaW1hdGlvbixcbiAgICByZW5kZXJlclNldHRpbmdzOiB7XG4gICAgICBwcmVzZXJ2ZUFzcGVjdFJhdGlvOiAneE1pZFlNaWQgc2xpY2UnXG4gICAgfVxuICB9O1xuXG4gIGFzeW5jIGZ1bmN0aW9uIEhhbmRsZVN1Ym1pdCgpIHtcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIGNvbnN0IGRhdGEgPSB7IGVtYWlsLCBwYXNzd29yZCB9O1xuXG4gICAgbGV0IHZhbGlkYXRpb24gPSBhd2FpdCBTaWduaW5WYWxpZGF0aW9uKGRhdGEpO1xuXG4gICAgaWYodmFsaWRhdGlvbikge1xuICAgICAgYXdhaXQgYXBpLnBvc3QoJy9zaWduaW4nLCBkYXRhKVxuICAgICAgLnRoZW4ocmVzcG9uc2UgPT4ge1xuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcIm92ZXJfbmFtZVwiLCByZXNwb25zZS5kYXRhLnVzZXIubmFtZSk7XG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwib3Zlcl90b2tlblwiLCByZXNwb25zZS5kYXRhLnRva2VuKTtcbiAgICAgICAgTWVzc2FnZShyZXNwb25zZSk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgIGhhbmRsZUF1dGhlbnRpY2F0ZWQoKVxuICAgICAgICB9LCAyMDAwKTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goZXJyb3IgPT4gIHtcbiAgICAgICAgTWVzc2FnZShlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2UpXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICB9LCAyMDAwKTtcbiAgICAgIH0pXG4gICAgfSBlbHNlIHtcbiAgICAgIE1lc3NhZ2UoXCJQcmVlbmNoYSB1bSBlbWFpbCB2w6FsaWRvIGUgdW1hIHNlbmhhIGRlIG5vIG3DrW5pbW8gNiBjYXJhY3RlcmVzIVwiKVxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgfSwgMjAwMCk7XG4gICAgfSAgIFxuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlQXV0aGVudGljYXRlZCgpIHtcbiAgICBsZXQgdG9rZW4gPSBhd2FpdCBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcIm92ZXJfdG9rZW5cIik7XG5cbiAgICBpZih0b2tlbikge1xuICAgICAgd2luZG93LmxvY2F0aW9uID0gXCIvXCI7XG4gICAgfVxuICB9XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBoYW5kbGVBdXRoZW50aWNhdGVkKCk7XG4gIH0sIFtdKVxuXG4gIHJldHVybihcbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmNvbnRhaW5lcn0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmZvcm19PlxuICAgICAgICA8VG9hc3RDb250YWluZXIgLz5cbiAgICAgICAgPGlucHV0IFxuICAgICAgICAgIGNsYXNzTmFtZT17c3R5bGVzLmlucHV0fVxuICAgICAgICAgIHR5cGU9XCJlbWFpbFwiIFxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRS1tYWlsXCIgXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9IFxuICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgIC8+XG4gICAgICAgIDxpbnB1dCBcbiAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5pbnB1dH1cbiAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIiBcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbmhhXCIgXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9IFxuICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgIC8+XG4gICAgICAgIDxMaW5rXG4gICAgICAgICAgaHJlZj1cIi9mb3Jnb3QtcGFzc3dvcmRcIlxuICAgICAgICA+IFxuICAgICAgICAgIDxhIGNsYXNzTmFtZT17c3R5bGVzLmZvcmdvdFBhc3N3b3JkfT5cbiAgICAgICAgICBFc3F1ZWNldSBzdWEgc2VuaGE/IFxuICAgICAgICAgIDwvYT5cbiAgICAgICAgPC9MaW5rPlxuICAgICAgICBcbiAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5idXR0b259XG4gICAgICAgICAgb25DbGljaz17SGFuZGxlU3VibWl0fVxuICAgICAgICA+XG4gICAgICAgICAgeyBsb2FkaW5nID8gXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmFuaW1hdGlvbn0+XG4gICAgICAgICAgICAgIDxMb3R0aWUgb3B0aW9ucz17ZGVmYXVsdE9wdGlvbnN9Lz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgIDogXG4gICAgICAgICAgICAgIFwiRW50cmFyXCJcbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxMaW5rXG4gICAgICAgICAgaHJlZj1cIi9zaWdudXBcIlxuICAgICAgICA+XG4gICAgICAgICAgPGEgY2xhc3NOYW1lPXtzdHlsZXMuc2lnbmlufT5BaW5kYSBuw6NvIHRlbSBjYWRhc3Rybz8gXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3N0eWxlcy5zcGFufT5DYWRhc3RyYS1zZSE8L3NwYW4+XG4gICAgICAgICAgPC9hPlxuICAgICAgICA8L0xpbms+XG4gICAgICAgIFxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgU2lnbkluO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==