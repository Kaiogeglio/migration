webpackHotUpdate_N_E("pages/signin",{

/***/ "./pages/signin/index.js":
/*!*******************************!*\
  !*** ./pages/signin/index.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-toastify */ "./node_modules/react-toastify/dist/react-toastify.esm.js");
/* harmony import */ var react_lottie__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-lottie */ "./node_modules/react-lottie/dist/index.js");
/* harmony import */ var react_lottie__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_lottie__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../styles/pages/Signin.module.css */ "./styles/pages/Signin.module.css");
/* harmony import */ var _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../services/api */ "./services/api.js");
/* harmony import */ var _utils_validation_SigninValidation__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../utils/validation/SigninValidation */ "./utils/validation/SigninValidation.js");
/* harmony import */ var _components_Message__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../components/Message */ "./components/Message/index.js");
/* harmony import */ var _assets_animation_9953_loading_round_json__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../assets/animation/9953-loading-round.json */ "./assets/animation/9953-loading-round.json");
var _assets_animation_9953_loading_round_json__WEBPACK_IMPORTED_MODULE_12___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../../assets/animation/9953-loading-round.json */ "./assets/animation/9953-loading-round.json", 1);




var _jsxFileName = "C:\\Users\\Kaio\\Desktop\\migration\\pages\\signin\\index.js",
    _s = $RefreshSig$();





 //Falta criar as classes





 // import logo from '../../assets/images/logo-overstack-novo.png';

function SignIn() {
  _s();

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(''),
      email = _useState[0],
      setEmail = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(''),
      password = _useState2[0],
      setPassword = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(false),
      loading = _useState3[0],
      setLoading = _useState3[1];

  var defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: _assets_animation_9953_loading_round_json__WEBPACK_IMPORTED_MODULE_12__,
    rendererSettings: {
      preserveAspectRatio: 'xMidYMid slice'
    }
  };

  function HandleSubmit() {
    return _HandleSubmit.apply(this, arguments);
  }

  function _HandleSubmit() {
    _HandleSubmit = Object(C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
      var data, validation;
      return C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              setLoading(true);
              data = {
                email: email,
                password: password
              };
              _context.next = 4;
              return Object(_utils_validation_SigninValidation__WEBPACK_IMPORTED_MODULE_10__["default"])(data);

            case 4:
              validation = _context.sent;

              if (!validation) {
                _context.next = 10;
                break;
              }

              _context.next = 8;
              return _services_api__WEBPACK_IMPORTED_MODULE_9__["default"].post('/signin', data).then(function (response) {
                localStorage.setItem("over_name", response.data.user.name);
                localStorage.setItem("over_token", response.data.token);
                Object(_components_Message__WEBPACK_IMPORTED_MODULE_11__["default"])(response);
                setTimeout(function () {
                  setLoading(false);
                  handleAuthenticated();
                }, 2000);
              })["catch"](function (error) {
                Object(_components_Message__WEBPACK_IMPORTED_MODULE_11__["default"])(error.response.data.message);
                setTimeout(function () {
                  setLoading(false);
                }, 2000);
              });

            case 8:
              _context.next = 12;
              break;

            case 10:
              Object(_components_Message__WEBPACK_IMPORTED_MODULE_11__["default"])("Preencha um email válido e uma senha de no mínimo 6 caracteres!");
              setTimeout(function () {
                setLoading(false);
              }, 2000);

            case 12:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));
    return _HandleSubmit.apply(this, arguments);
  }

  function handleAuthenticated() {
    return _handleAuthenticated.apply(this, arguments);
  }

  function _handleAuthenticated() {
    _handleAuthenticated = Object(C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
      var token;
      return C_Users_Kaio_Desktop_migration_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return localStorage.getItem("over_token");

            case 2:
              token = _context2.sent;

              if (token) {
                window.location = "/";
              }

            case 4:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));
    return _handleAuthenticated.apply(this, arguments);
  }

  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])(function () {
    handleAuthenticated();
  }, []);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
    className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.container,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
      className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.form,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(react_toastify__WEBPACK_IMPORTED_MODULE_6__["ToastContainer"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("input", {
        className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.input,
        type: "email",
        placeholder: "E-mail",
        onChange: function onChange(e) {
          return setEmail(e.target.value);
        },
        required: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 82,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("input", {
        className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.input,
        type: "password",
        placeholder: "Senha",
        onChange: function onChange(e) {
          return setPassword(e.target.value);
        },
        required: true
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 89,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
        href: "/forgot-password",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("a", {
          className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.forgotPassword,
          children: "Esqueceu sua senha?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 99,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("button", {
        className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.button,
        onClick: HandleSubmit,
        children: loading ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("div", {
          className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.animation,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(react_lottie__WEBPACK_IMPORTED_MODULE_7___default.a, {
            options: defaultOptions
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 110,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 109,
          columnNumber: 13
        }, this) : "Entrar"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 104,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_5___default.a, {
        href: "/signup",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("a", {
          className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.signin,
          children: ["Ainda n\xE3o tem cadastro?", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__["jsxDEV"])("span", {
            className: _styles_pages_Signin_module_css__WEBPACK_IMPORTED_MODULE_8___default.a.span,
            children: "Cadastra-se!"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 121,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 120,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 117,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 77,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 76,
    columnNumber: 5
  }, this);
}

_s(SignIn, "NTuBuTewpujiBTusgv9ZxvtgOf0=");

_c = SignIn;
/* harmony default export */ __webpack_exports__["default"] = (SignIn);

var _c;

$RefreshReg$(_c, "SignIn");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvc2lnbmluL2luZGV4LmpzIl0sIm5hbWVzIjpbIlNpZ25JbiIsInVzZVN0YXRlIiwiZW1haWwiLCJzZXRFbWFpbCIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImRlZmF1bHRPcHRpb25zIiwibG9vcCIsImF1dG9wbGF5IiwiYW5pbWF0aW9uRGF0YSIsImNoZWNrQW5pbWF0aW9uIiwicmVuZGVyZXJTZXR0aW5ncyIsInByZXNlcnZlQXNwZWN0UmF0aW8iLCJIYW5kbGVTdWJtaXQiLCJkYXRhIiwiU2lnbmluVmFsaWRhdGlvbiIsInZhbGlkYXRpb24iLCJhcGkiLCJwb3N0IiwidGhlbiIsInJlc3BvbnNlIiwibG9jYWxTdG9yYWdlIiwic2V0SXRlbSIsInVzZXIiLCJuYW1lIiwidG9rZW4iLCJNZXNzYWdlIiwic2V0VGltZW91dCIsImhhbmRsZUF1dGhlbnRpY2F0ZWQiLCJlcnJvciIsIm1lc3NhZ2UiLCJnZXRJdGVtIiwid2luZG93IiwibG9jYXRpb24iLCJ1c2VFZmZlY3QiLCJzdHlsZXMiLCJjb250YWluZXIiLCJmb3JtIiwiaW5wdXQiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJmb3Jnb3RQYXNzd29yZCIsImJ1dHRvbiIsImFuaW1hdGlvbiIsInNpZ25pbiIsInNwYW4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0NBR0E7O0FBQ0E7QUFFQTtBQUVBO0FBQ0E7Q0FHQTs7QUFFQSxTQUFTQSxNQUFULEdBQWtCO0FBQUE7O0FBQUEsa0JBQ1VDLHNEQUFRLENBQUMsRUFBRCxDQURsQjtBQUFBLE1BQ1RDLEtBRFM7QUFBQSxNQUNGQyxRQURFOztBQUFBLG1CQUVnQkYsc0RBQVEsQ0FBQyxFQUFELENBRnhCO0FBQUEsTUFFVEcsUUFGUztBQUFBLE1BRUNDLFdBRkQ7O0FBQUEsbUJBR2NKLHNEQUFRLENBQUMsS0FBRCxDQUh0QjtBQUFBLE1BR1RLLE9BSFM7QUFBQSxNQUdBQyxVQUhBOztBQUtoQixNQUFNQyxjQUFjLEdBQUc7QUFDckJDLFFBQUksRUFBRSxJQURlO0FBRXJCQyxZQUFRLEVBQUUsSUFGVztBQUdyQkMsaUJBQWEsRUFBRUMsdUVBSE07QUFJckJDLG9CQUFnQixFQUFFO0FBQ2hCQyx5QkFBbUIsRUFBRTtBQURMO0FBSkcsR0FBdkI7O0FBTGdCLFdBY0RDLFlBZEM7QUFBQTtBQUFBOztBQUFBO0FBQUEsMlJBY2hCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNFUix3QkFBVSxDQUFDLElBQUQsQ0FBVjtBQUNNUyxrQkFGUixHQUVlO0FBQUVkLHFCQUFLLEVBQUxBLEtBQUY7QUFBU0Usd0JBQVEsRUFBUkE7QUFBVCxlQUZmO0FBQUE7QUFBQSxxQkFJeUJhLG1GQUFnQixDQUFDRCxJQUFELENBSnpDOztBQUFBO0FBSU1FLHdCQUpOOztBQUFBLG1CQU1LQSxVQU5MO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEscUJBT1VDLHFEQUFHLENBQUNDLElBQUosQ0FBUyxTQUFULEVBQW9CSixJQUFwQixFQUNMSyxJQURLLENBQ0EsVUFBQUMsUUFBUSxFQUFJO0FBQ2hCQyw0QkFBWSxDQUFDQyxPQUFiLENBQXFCLFdBQXJCLEVBQWtDRixRQUFRLENBQUNOLElBQVQsQ0FBY1MsSUFBZCxDQUFtQkMsSUFBckQ7QUFDQUgsNEJBQVksQ0FBQ0MsT0FBYixDQUFxQixZQUFyQixFQUFtQ0YsUUFBUSxDQUFDTixJQUFULENBQWNXLEtBQWpEO0FBQ0FDLG9GQUFPLENBQUNOLFFBQUQsQ0FBUDtBQUNBTywwQkFBVSxDQUFDLFlBQU07QUFDZnRCLDRCQUFVLENBQUMsS0FBRCxDQUFWO0FBQ0F1QixxQ0FBbUI7QUFDcEIsaUJBSFMsRUFHUCxJQUhPLENBQVY7QUFJRCxlQVRLLFdBVUMsVUFBQUMsS0FBSyxFQUFLO0FBQ2ZILG9GQUFPLENBQUNHLEtBQUssQ0FBQ1QsUUFBTixDQUFlTixJQUFmLENBQW9CZ0IsT0FBckIsQ0FBUDtBQUNBSCwwQkFBVSxDQUFDLFlBQU07QUFDZnRCLDRCQUFVLENBQUMsS0FBRCxDQUFWO0FBQ0QsaUJBRlMsRUFFUCxJQUZPLENBQVY7QUFHRCxlQWZLLENBUFY7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBd0JJcUIsa0ZBQU8sQ0FBQyxpRUFBRCxDQUFQO0FBQ0FDLHdCQUFVLENBQUMsWUFBTTtBQUNmdEIsMEJBQVUsQ0FBQyxLQUFELENBQVY7QUFDRCxlQUZTLEVBRVAsSUFGTyxDQUFWOztBQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQWRnQjtBQUFBO0FBQUE7O0FBQUEsV0E2Q0R1QixtQkE3Q0M7QUFBQTtBQUFBOztBQUFBO0FBQUEsa1NBNkNoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUNvQlAsWUFBWSxDQUFDVSxPQUFiLENBQXFCLFlBQXJCLENBRHBCOztBQUFBO0FBQ01OLG1CQUROOztBQUdFLGtCQUFHQSxLQUFILEVBQVU7QUFDUk8sc0JBQU0sQ0FBQ0MsUUFBUCxHQUFrQixHQUFsQjtBQUNEOztBQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBN0NnQjtBQUFBO0FBQUE7O0FBcURoQkMseURBQVMsQ0FBQyxZQUFNO0FBQ2ROLHVCQUFtQjtBQUNwQixHQUZRLEVBRU4sRUFGTSxDQUFUO0FBSUEsc0JBQ0U7QUFBSyxhQUFTLEVBQUVPLHNFQUFNLENBQUNDLFNBQXZCO0FBQUEsMkJBQ0U7QUFBSyxlQUFTLEVBQUVELHNFQUFNLENBQUNFLElBQXZCO0FBQUEsOEJBQ0UscUVBQUMsNkRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBS0U7QUFDRSxpQkFBUyxFQUFFRixzRUFBTSxDQUFDRyxLQURwQjtBQUVFLFlBQUksRUFBQyxPQUZQO0FBR0UsbUJBQVcsRUFBQyxRQUhkO0FBSUUsZ0JBQVEsRUFBRSxrQkFBQ0MsQ0FBRDtBQUFBLGlCQUFPdEMsUUFBUSxDQUFDc0MsQ0FBQyxDQUFDQyxNQUFGLENBQVNDLEtBQVYsQ0FBZjtBQUFBLFNBSlo7QUFLRSxnQkFBUTtBQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FMRixlQVlFO0FBQ0UsaUJBQVMsRUFBRU4sc0VBQU0sQ0FBQ0csS0FEcEI7QUFFRSxZQUFJLEVBQUMsVUFGUDtBQUdFLG1CQUFXLEVBQUMsT0FIZDtBQUlFLGdCQUFRLEVBQUUsa0JBQUNDLENBQUQ7QUFBQSxpQkFBT3BDLFdBQVcsQ0FBQ29DLENBQUMsQ0FBQ0MsTUFBRixDQUFTQyxLQUFWLENBQWxCO0FBQUEsU0FKWjtBQUtFLGdCQUFRO0FBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVpGLGVBbUJFLHFFQUFDLGdEQUFEO0FBQ0UsWUFBSSxFQUFDLGtCQURQO0FBQUEsK0JBR0U7QUFBRyxtQkFBUyxFQUFFTixzRUFBTSxDQUFDTyxjQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FuQkYsZUEyQkU7QUFDRSxpQkFBUyxFQUFFUCxzRUFBTSxDQUFDUSxNQURwQjtBQUVFLGVBQU8sRUFBRTlCLFlBRlg7QUFBQSxrQkFJSVQsT0FBTyxnQkFDUDtBQUFLLG1CQUFTLEVBQUUrQixzRUFBTSxDQUFDUyxTQUF2QjtBQUFBLGlDQUNFLHFFQUFDLG1EQUFEO0FBQVEsbUJBQU8sRUFBRXRDO0FBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURPLEdBTUw7QUFWTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBM0JGLGVBd0NFLHFFQUFDLGdEQUFEO0FBQ0UsWUFBSSxFQUFDLFNBRFA7QUFBQSwrQkFHRTtBQUFHLG1CQUFTLEVBQUU2QixzRUFBTSxDQUFDVSxNQUFyQjtBQUFBLGdFQUNFO0FBQU0scUJBQVMsRUFBRVYsc0VBQU0sQ0FBQ1csSUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFxREQ7O0dBOUdRaEQsTTs7S0FBQUEsTTtBQWdITUEscUVBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvc2lnbmluLjBkMTg4MTcyZmUyM2U5NTljZWJlLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnO1xuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcbmltcG9ydCB7IFRvYXN0Q29udGFpbmVyIH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IExvdHRpZSBmcm9tICdyZWFjdC1sb3R0aWUnO1xuXG4vL0ZhbHRhIGNyaWFyIGFzIGNsYXNzZXNcbmltcG9ydCBzdHlsZXMgZnJvbSAnLi4vLi4vc3R5bGVzL3BhZ2VzL1NpZ25pbi5tb2R1bGUuY3NzJztcblxuaW1wb3J0IGFwaSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGknO1xuXG5pbXBvcnQgU2lnbmluVmFsaWRhdGlvbiBmcm9tICcuLi8uLi91dGlscy92YWxpZGF0aW9uL1NpZ25pblZhbGlkYXRpb24nO1xuaW1wb3J0IE1lc3NhZ2UgZnJvbSAnLi4vLi4vY29tcG9uZW50cy9NZXNzYWdlJztcblxuaW1wb3J0IGNoZWNrQW5pbWF0aW9uIGZyb20gJy4uLy4uL2Fzc2V0cy9hbmltYXRpb24vOTk1My1sb2FkaW5nLXJvdW5kLmpzb24nO1xuLy8gaW1wb3J0IGxvZ28gZnJvbSAnLi4vLi4vYXNzZXRzL2ltYWdlcy9sb2dvLW92ZXJzdGFjay1ub3ZvLnBuZyc7XG5cbmZ1bmN0aW9uIFNpZ25JbigpIHtcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgY29uc3QgZGVmYXVsdE9wdGlvbnMgPSB7XG4gICAgbG9vcDogdHJ1ZSxcbiAgICBhdXRvcGxheTogdHJ1ZSwgXG4gICAgYW5pbWF0aW9uRGF0YTogY2hlY2tBbmltYXRpb24sXG4gICAgcmVuZGVyZXJTZXR0aW5nczoge1xuICAgICAgcHJlc2VydmVBc3BlY3RSYXRpbzogJ3hNaWRZTWlkIHNsaWNlJ1xuICAgIH1cbiAgfTtcblxuICBhc3luYyBmdW5jdGlvbiBIYW5kbGVTdWJtaXQoKSB7XG4gICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICBjb25zdCBkYXRhID0geyBlbWFpbCwgcGFzc3dvcmQgfTtcblxuICAgIGxldCB2YWxpZGF0aW9uID0gYXdhaXQgU2lnbmluVmFsaWRhdGlvbihkYXRhKTtcblxuICAgIGlmKHZhbGlkYXRpb24pIHtcbiAgICAgIGF3YWl0IGFwaS5wb3N0KCcvc2lnbmluJywgZGF0YSlcbiAgICAgIC50aGVuKHJlc3BvbnNlID0+IHtcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJvdmVyX25hbWVcIiwgcmVzcG9uc2UuZGF0YS51c2VyLm5hbWUpO1xuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcIm92ZXJfdG9rZW5cIiwgcmVzcG9uc2UuZGF0YS50b2tlbik7XG4gICAgICAgIE1lc3NhZ2UocmVzcG9uc2UpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgICBoYW5kbGVBdXRoZW50aWNhdGVkKClcbiAgICAgICAgfSwgMjAwMCk7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKGVycm9yID0+ICB7XG4gICAgICAgIE1lc3NhZ2UoZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlKVxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgfSwgMjAwMCk7XG4gICAgICB9KVxuICAgIH0gZWxzZSB7XG4gICAgICBNZXNzYWdlKFwiUHJlZW5jaGEgdW0gZW1haWwgdsOhbGlkbyBlIHVtYSBzZW5oYSBkZSBubyBtw61uaW1vIDYgY2FyYWN0ZXJlcyFcIilcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgIH0sIDIwMDApO1xuICAgIH0gICBcbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZUF1dGhlbnRpY2F0ZWQoKSB7XG4gICAgbGV0IHRva2VuID0gYXdhaXQgbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJvdmVyX3Rva2VuXCIpO1xuXG4gICAgaWYodG9rZW4pIHtcbiAgICAgIHdpbmRvdy5sb2NhdGlvbiA9IFwiL1wiO1xuICAgIH1cbiAgfVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaGFuZGxlQXV0aGVudGljYXRlZCgpO1xuICB9LCBbXSlcblxuICByZXR1cm4oXG4gICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5jb250YWluZXJ9PlxuICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5mb3JtfT5cbiAgICAgICAgPFRvYXN0Q29udGFpbmVyIC8+XG4gICAgICAgIHsvKiA8SW1hZ2UgXG4gICAgICAgICAgc3JjPXtsb2dvfVxuICAgICAgICAvPiAqL31cbiAgICAgICAgPGlucHV0IFxuICAgICAgICAgIGNsYXNzTmFtZT17c3R5bGVzLmlucHV0fVxuICAgICAgICAgIHR5cGU9XCJlbWFpbFwiIFxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRS1tYWlsXCIgXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbWFpbChlLnRhcmdldC52YWx1ZSl9IFxuICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgIC8+XG4gICAgICAgIDxpbnB1dCBcbiAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5pbnB1dH1cbiAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIiBcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbmhhXCIgXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9IFxuICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgIC8+XG4gICAgICAgIDxMaW5rXG4gICAgICAgICAgaHJlZj1cIi9mb3Jnb3QtcGFzc3dvcmRcIlxuICAgICAgICA+IFxuICAgICAgICAgIDxhIGNsYXNzTmFtZT17c3R5bGVzLmZvcmdvdFBhc3N3b3JkfT5cbiAgICAgICAgICBFc3F1ZWNldSBzdWEgc2VuaGE/IFxuICAgICAgICAgIDwvYT5cbiAgICAgICAgPC9MaW5rPlxuICAgICAgICBcbiAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5idXR0b259XG4gICAgICAgICAgb25DbGljaz17SGFuZGxlU3VibWl0fVxuICAgICAgICA+XG4gICAgICAgICAgeyBsb2FkaW5nID8gXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmFuaW1hdGlvbn0+XG4gICAgICAgICAgICAgIDxMb3R0aWUgb3B0aW9ucz17ZGVmYXVsdE9wdGlvbnN9Lz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgIDogXG4gICAgICAgICAgICAgIFwiRW50cmFyXCJcbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDxMaW5rXG4gICAgICAgICAgaHJlZj1cIi9zaWdudXBcIlxuICAgICAgICA+XG4gICAgICAgICAgPGEgY2xhc3NOYW1lPXtzdHlsZXMuc2lnbmlufT5BaW5kYSBuw6NvIHRlbSBjYWRhc3Rybz8gXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e3N0eWxlcy5zcGFufT5DYWRhc3RyYS1zZSE8L3NwYW4+XG4gICAgICAgICAgPC9hPlxuICAgICAgICA8L0xpbms+XG4gICAgICAgIFxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgU2lnbkluO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==